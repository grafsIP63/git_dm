#include <math.h>
#include "files.h"
#include "searching.h"
//int a = 0;
namespace Searching
{
	int binary(int *array, int element, int size, int start, int finish)
	{
		//	cout << "s";
		int pointer = size;
		//start = 0;
		//finish = size - 1;

		pointer = pointer / 2;//left element
		pointer += start;
		if (pointer - 1 < 0 || pointer > finish)
		{
			return -1;
		}
		if (array[pointer - 1] >= element)
		{
			//if (a>0)return a;
			if (array[pointer - 1] == element)
			{
				//a = pointer - 1;
				return pointer - 1;

			}
			else
			{
				binary(array, element, size / 2, start, pointer);
			}
		}
		else
		{
			//if (a>0)return a;
			if (array[pointer] == element)
			{
				//a = pointer;
				return pointer;

			}
			else
			{
				binary(array, element, finish - pointer + 1, pointer, finish);
			}
		}

	}

	int  Binary(int *&array, int element, int size, int start, int finish)
	{
		if (element > array[finish])
		{
			return -1;
		}
		int pointer = size / 2;//right
		int iteration = 0;
		while (pointer <= finish && pointer > 0 && array[pointer] != element)
		{
			iteration++;
			if (array[pointer] > element)
			{
				size = size / 2;
				finish = (pointer - 1);
				pointer = (finish - start + 1) / 2;
			}
			else
			{
				start = pointer;
				size = finish - pointer + 1;
				pointer = size / 2 + start;
			}
		}
		IterationIn(iteration);
		if (array[pointer] != element)
		{
			return -1;
		}
		else
		{
			return pointer;
		}
	}
	int  UBinary(int *&array, int K, int i, int m)
	{
		int iteration = 0;
		while (m != 0)
		{
			iteration++;
			if (K == array[i])
			{
				return i;
			}
			if (K < array[i])
			{
				i--;
				i = i - m / 2;
				m = m / 2;
			}
			else
			{
				if (i == i + m / 2)
					i = i + m / 2 + 1;
				else
					i = i + m / 2;
				m = m / 2;
			}
		}
		IterationIn(iteration);
		if (array[i] != K)
		{
			return -1;
		}
		else
		{
			return i;
		}
	}
	int linear(int *array, int element, int size)
	{
		int result = 0;
		int iteration = 0;
		while (array[result] != element)
		{
			iteration++;
			result++;
			if (result > size)
			{
				return -1;
			}
		}
		IterationIn(iteration);
		return result;
	}

	int  ubinary(int array[], int K, int i, int m)
	{

		if (K == array[i])
		{
			return i;
		}
		else
		{
			if (K < array[i])
			{
				i--;
				if (m == 0)
				{
					return -1;
				}
				else
				{
					i = i - m / 2;
					m = m / 2;
					ubinary(array, K, i, m);
				}
			}
			else
			{

				if (m == 0)
				{
					return -1;
				}
				else
				{
					i = i + m / 2;
					m = m / 2;
					ubinary(array, K, i, m);
				}
			}
		}
	}

	int Alone(int *&array, int K, int N)
	{
		int start = 1;
		int end = log(N) + 2;
		int *DELTA = new int[end - start + 1];
		for (int i = start; i < end; i++)
		{
			DELTA[i] = (N + pow(2., i - 1)) / pow(2., i);
		}
		int j = 1; int i = 0;
		while (i > 0 && i < N && j >= 1 && DELTA[j] != 0)
		{
			if (K == array[i])
			{
				return i;
			}

			if (K < array[i])
			{
				i = i - DELTA[j];
				j = j + 1;
			}
			else
			{
				i = i + DELTA[j];
				j = j + 1;
			}
		}

		if (array[i] != K)
		{
			return -1;
		}
		else
		{
			return i;
		}
	}


	int ABinary(int *&array, int K, int size)
	{


		if (K > array[999])
		{
			return -1;
		}

		int it = 0;
		int *arr = new int[size + 1];
		for (int i = 1; i <= size; i++)
		{
			arr[i] = array[i - 1];
		}
		int c = log2(size) + 2;
		int *D = new int[c];
		D[0] = 0;
		for (int j = 1; j < c; j++)
		{
			D[j] = (size + pow(2, j - 1)) / pow(2, j);
			//cout << " j :" << j << ";" << D[j] << endl;
		}
		//D[9] = 2;
		//D[10] = 1;
		int i = D[1], j = 2;
		while (i > 0 && i < size)
		{
			it++;
			if (D[j] == 0)
			{
				if (i <= 10 && i > 0 && D[i] == K)
				{
					IterationIn(it);
					return i - 1;
				}
				else
				{
					return -1;
				}
			}
			else
			{
				if (arr[i] == K)
				{
					IterationIn(it);
					return i - 1;
				}
				else
				{
					if (arr[i] > K)
					{
						i = i - D[j];
						j = j + 1;
					}
					else
					{
						i = i + D[j];
						j = j + 1;
					}
				}
			}
		}
		if (i > 0 && i < size && arr[i] != K)
		{
			return -1;
		}
		else
		{
			IterationIn(it);
			return i - 1;
		}
	}

	/*int Shar(int *&array, int K, int n)
	{
		int i = pow(2, log(n));
		if (K < array[i])
		{
			return ABinary(array, K, n);
		}
		else
		{
			return Binary(array, K, n, 0, n - 1);
		}
	}*/

	int Shar(int *&array, int K, int N)
	{
		int iteration = 0;
		int k = log(N);
		int I = pow(2, k);
		int sigma = I;

		if (K < array[I])
		{
			iteration++;
			int size = I;
			int *arr = new int[size + 1];
			for (int i = 1; i <= size; i++)
			{
				arr[i] = array[i - 1];
			}
			int c = log(size) + 4;
			int *D = new int[c];
			D[0] = 0;
			for (int j = 1; j < log(size) + 4; j++)
			{
				D[j] = (size + pow(2, j - 1)) / pow(2, j);
				//cout << " j :" << j << ";" << D[j] << endl;
			}
			//D[9] = 2;
			//D[10] = 1;
			int i = D[1], j = 2;
			while (i > 0 && i < size)
			{
				iteration++;
				if (D[j] == 0)
				{
					if (i <= 10 && i > 0 && D[i] == K)
					{
						IterationIn(iteration);
						return i - 1;
					}
					else
						return -1;
				}
				else
				{
					if (arr[i] == K)
					{
						IterationIn(iteration);
						return i - 1;
					}
					else
					{
						if (arr[i] > K)
						{
							i = i - D[j];
							j = j + 1;
						}
						else
						{
							i = i + D[j];
							j = j + 1;
						}
					}
				}
			}
			if (i > 0 && i < size && arr[i] != K)
			{
				return -1;
			}
			else
			{
				IterationIn(iteration);
				return i - 1;
			}
		}
		else
		{
			int element = K;
			int pointer = N / 2;//right
			int iteration = 0;
			int size = N / 2;
			int start = I;
			int finish = N - 1;
			while (pointer <= finish && pointer > 0 && array[pointer] != element)
			{
				iteration++;
				if (array[pointer] > element)
				{
					int size = size / 2;
					finish = (pointer - 1);
					pointer = (finish - start + 1) / 2;
				}
				else
				{
					start = pointer;
					size = finish - pointer + 1;
					pointer = size / 2 + start;
				}
			}
			if (array[pointer] != element)
			{
				return -1;
			}
			else
			{
				IterationIn(iteration);
				return pointer;
			}
		}

	}



	int Shara(int *&array, int K, int n)
	{
		int fin = 0;
		int iterator = 0;
		int *arr = new int[n + 1];
		arr[0] = 0;

		for (int i = 1; i < n + 1; i++)
		{
			arr[i] = array[i - 1];
		}

		int k = log2(n);
		int i = pow(2., k);
		int sigma = 0;

		if (K < arr[i])
		{
			int it = 2;
			sigma = pow(2., k - 1);
			i = i - sigma;
			while (sigma >= 0 && k - it >= 0)
			{
				iterator++;
				if (K == arr[i])
				{
					IterationIn(iterator);
					return i - 1;
				}
				else
				{
					sigma = pow(2., k - it);
					it++;
					if (K < arr[i])
					{
						i = i - sigma;
					}
					else
					{
						i = i + sigma;
					}
				}
				fin = i;
			}
		}
		else
		{
			int l = log2(n - pow(2., k) + 1);
			int i = n + 1 - pow(2., l);
			int it = 1;

			while (i <= n && i >= 0 && l - it >= 0)
			{
				iterator++;
				if (K == arr[i])
				{
					IterationIn(iterator);
					return i - 1;
				}
				else
				{
					if (K < arr[i])
					{
						i = i - pow(2., l - it);
					}
					else
					{
						i = i + pow(2., l - it);
					}
					it++;
				}
				fin = i;
			}
		}
		int t = iterator;
		IterationIn(iterator);
		if (arr[fin] == K)
		{
			IterationIn(iterator);
			return fin - 1;
		}
		else
		{
			return -1;
		}
	}
}