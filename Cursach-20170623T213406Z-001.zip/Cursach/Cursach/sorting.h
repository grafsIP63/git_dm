#pragma once

namespace Sorting
{
	void buble(int *&array, int size);
}
