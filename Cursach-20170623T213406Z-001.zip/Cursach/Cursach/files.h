#pragma once

void  InFile(int *&array, int size);


void FromFile(int *&array, int size);


void selectedIn(int number);


int selectedOut();


void IterationIn(int sum);


int IterationOut();

void ABIn(int a, int b);

int* ABOut();