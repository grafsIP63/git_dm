#include <stdlib.h>
#include <ctime>
#include <time.h>
#include "files.h"
#include "generator.h"
//#define SIZE 1000

using namespace std;


namespace Generator
{
	int Linear(int *array, int element, int size)
	{
		int result = 0;
		int iteration = 0;
		while (array[result] != element)
		{
			iteration++;
			result++;
			if (result > size)
			{
				return -1;
			}
		}
		IterationIn(iteration);
		return result;
	}

	void generate(int *&array, int from, int to)
	{
		//int SIZE = abs(to) - abs(from);
		srand(time(0));
		array = new int[SIZE];

		for (int i = 0; i < SIZE; i++)
		{
			array[i] = 0;
		}

		int curr = 0;

		for (int i = 0; i < SIZE; i++)
		{
			curr = rand() % (from - to + 1) + from;
			while (Linear(array, curr, SIZE) != -1)
			{
				curr = rand() % (from - to + 1) + from;
			}
			array[i] = curr;
		}
	}
}