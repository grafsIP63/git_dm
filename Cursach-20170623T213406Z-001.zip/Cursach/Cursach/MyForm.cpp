﻿#include "MyForm.h"
using namespace System;
using namespace System::Windows::Forms;

[STAThread]
void main(cli::array<String^>^ arg) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);

	Cursach::MyForm form;  //нужно указать имя своего проекта (а не test_project)
	Application::Run(%form);
}

