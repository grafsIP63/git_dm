#pragma once



namespace Searching
{
	int binary(int *array, int element, int size, int start, int finish);


	int  Binary(int *&array, int element, int sizeSS, int start, int finish);

	int  UBinary(int *&array, int K, int i, int m);

	int linear(int *array, int element, int size);


	int  ubinary(int array[], int K, int i, int m);


	int Alone(int *&array, int K, int N);


	int ABinary(int *&array, int K, int size);


	int Shar(int *&array, int K, int N);

	int Shara(int *&array, int K, int n);

}
