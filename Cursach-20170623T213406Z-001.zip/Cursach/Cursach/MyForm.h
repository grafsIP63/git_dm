﻿#pragma once
#include "libraries.h"
/*#include "files.h"
#include <iostream>
#include <ctime>
#include <time.h>
#include "searching.h"*/

#define N 500 //for timing

bool b = false;
//using namespace Searching;

namespace Cursach {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::GroupBox^  gbGenerate;
	protected:
	private: System::Windows::Forms::Button^  button1;

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label1;





	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::RadioButton^  radioButton4;
	private: System::Windows::Forms::RadioButton^  radioButton3;
	private: System::Windows::Forms::RadioButton^  radioButton2;
	private: System::Windows::Forms::RadioButton^  radioButton1;
	private: System::Windows::Forms::GroupBox^  groupBox2;

	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  button2;

	private: System::Windows::Forms::GroupBox^  groupBox3;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::GroupBox^  groupBox4;
	private: System::Windows::Forms::Label^  Iteration;


	private: System::Windows::Forms::Label^  TIME;

	private: System::Windows::Forms::DataGridView^  Table;
	private: System::Windows::Forms::RichTextBox^  richTextBox1;

	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::NumericUpDown^  txtTo;
	private: System::Windows::Forms::NumericUpDown^  txtFrom;
	private: System::Windows::Forms::NumericUpDown^  textBox3;






	protected:

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->gbGenerate = (gcnew System::Windows::Forms::GroupBox());
			this->txtTo = (gcnew System::Windows::Forms::NumericUpDown());
			this->txtFrom = (gcnew System::Windows::Forms::NumericUpDown());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton4 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton3 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton2 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton1 = (gcnew System::Windows::Forms::RadioButton());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->Iteration = (gcnew System::Windows::Forms::Label());
			this->TIME = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->Table = (gcnew System::Windows::Forms::DataGridView());
			this->textBox3 = (gcnew System::Windows::Forms::NumericUpDown());
			this->gbGenerate->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->txtTo))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->txtFrom))->BeginInit();
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox4->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Table))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->textBox3))->BeginInit();
			this->SuspendLayout();
			// 
			// gbGenerate
			// 
			this->gbGenerate->Controls->Add(this->txtTo);
			this->gbGenerate->Controls->Add(this->txtFrom);
			this->gbGenerate->Controls->Add(this->button1);
			this->gbGenerate->Controls->Add(this->label2);
			this->gbGenerate->Controls->Add(this->label1);
			this->gbGenerate->Location = System::Drawing::Point(12, 12);
			this->gbGenerate->Name = L"gbGenerate";
			this->gbGenerate->Size = System::Drawing::Size(241, 129);
			this->gbGenerate->TabIndex = 0;
			this->gbGenerate->TabStop = false;
			this->gbGenerate->Text = L"Диапазон";
			// 
			// txtTo
			// 
			this->txtTo->Location = System::Drawing::Point(126, 46);
			this->txtTo->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 20000000, 0, 0, 0 });
			this->txtTo->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 2000000, 0, 0, System::Int32::MinValue });
			this->txtTo->Name = L"txtTo";
			this->txtTo->Size = System::Drawing::Size(100, 20);
			this->txtTo->TabIndex = 7;
			// 
			// txtFrom
			// 
			this->txtFrom->Location = System::Drawing::Point(6, 46);
			this->txtFrom->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 20000000, 0, 0, 0 });
			this->txtFrom->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 2000000, 0, 0, System::Int32::MinValue });
			this->txtFrom->Name = L"txtFrom";
			this->txtFrom->Size = System::Drawing::Size(100, 20);
			this->txtFrom->TabIndex = 6;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(7, 72);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(219, 51);
			this->button1->TabIndex = 5;
			this->button1->Text = L"Сгенерировать";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click_1);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(123, 29);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(22, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"До";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(3, 29);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(20, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"От";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->radioButton4);
			this->groupBox1->Controls->Add(this->radioButton3);
			this->groupBox1->Controls->Add(this->radioButton2);
			this->groupBox1->Controls->Add(this->radioButton1);
			this->groupBox1->Location = System::Drawing::Point(259, 12);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(187, 113);
			this->groupBox1->TabIndex = 2;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Метод поиска";
			// 
			// radioButton4
			// 
			this->radioButton4->AutoSize = true;
			this->radioButton4->Location = System::Drawing::Point(15, 89);
			this->radioButton4->Name = L"radioButton4";
			this->radioButton4->Size = System::Drawing::Size(52, 17);
			this->radioButton4->TabIndex = 3;
			this->radioButton4->TabStop = true;
			this->radioButton4->Text = L"Шара";
			this->radioButton4->UseVisualStyleBackColor = true;
			// 
			// radioButton3
			// 
			this->radioButton3->AutoSize = true;
			this->radioButton3->Location = System::Drawing::Point(15, 65);
			this->radioButton3->Name = L"radioButton3";
			this->radioButton3->Size = System::Drawing::Size(142, 17);
			this->radioButton3->TabIndex = 2;
			this->radioButton3->TabStop = true;
			this->radioButton3->Text = L"Однородный бинарный";
			this->radioButton3->UseVisualStyleBackColor = true;
			// 
			// radioButton2
			// 
			this->radioButton2->AutoSize = true;
			this->radioButton2->Location = System::Drawing::Point(15, 42);
			this->radioButton2->Name = L"radioButton2";
			this->radioButton2->Size = System::Drawing::Size(76, 17);
			this->radioButton2->TabIndex = 1;
			this->radioButton2->TabStop = true;
			this->radioButton2->Text = L"Бинарный";
			this->radioButton2->UseVisualStyleBackColor = true;
			// 
			// radioButton1
			// 
			this->radioButton1->AutoSize = true;
			this->radioButton1->Location = System::Drawing::Point(15, 19);
			this->radioButton1->Name = L"radioButton1";
			this->radioButton1->Size = System::Drawing::Size(77, 17);
			this->radioButton1->TabIndex = 0;
			this->radioButton1->TabStop = true;
			this->radioButton1->Text = L"Линейный";
			this->radioButton1->UseVisualStyleBackColor = true;
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->label10);
			this->groupBox2->Controls->Add(this->Iteration);
			this->groupBox2->Controls->Add(this->TIME);
			this->groupBox2->Controls->Add(this->label5);
			this->groupBox2->Controls->Add(this->label3);
			this->groupBox2->Location = System::Drawing::Point(452, 77);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(200, 189);
			this->groupBox2->TabIndex = 3;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"Информация";
			// 
			// label10
			// 
			this->label10->Font = (gcnew System::Drawing::Font(L"Modern No. 20", 8.249999F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->Location = System::Drawing::Point(15, 135);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(176, 30);
			this->label10->TabIndex = 7;
			this->label10->Text = L"Copyright(C) 2017 - 2021 Dima Sheludko";
			// 
			// Iteration
			// 
			this->Iteration->Location = System::Drawing::Point(106, 79);
			this->Iteration->Name = L"Iteration";
			this->Iteration->Size = System::Drawing::Size(74, 14);
			this->Iteration->TabIndex = 5;
			// 
			// TIME
			// 
			this->TIME->Location = System::Drawing::Point(106, 29);
			this->TIME->Name = L"TIME";
			this->TIME->Size = System::Drawing::Size(74, 14);
			this->TIME->TabIndex = 3;
			// 
			// label5
			// 
			this->label5->Location = System::Drawing::Point(15, 70);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(85, 48);
			this->label5->TabIndex = 2;
			this->label5->Text = L"Количество итераций :";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(15, 30);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(85, 13);
			this->label3->TabIndex = 0;
			this->label3->Text = L"Время поиска :";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(462, 14);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(190, 51);
			this->button2->TabIndex = 4;
			this->button2->Text = L"Поиск";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->textBox3);
			this->groupBox3->Location = System::Drawing::Point(260, 132);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(186, 134);
			this->groupBox3->TabIndex = 7;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"Данные";
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->richTextBox1);
			this->groupBox4->Location = System::Drawing::Point(260, 272);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(383, 124);
			this->groupBox4->TabIndex = 8;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = L"Результат";
			// 
			// richTextBox1
			// 
			this->richTextBox1->BackColor = System::Drawing::SystemColors::Control;
			this->richTextBox1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->richTextBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 72, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->richTextBox1->Location = System::Drawing::Point(7, 19);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(365, 89);
			this->richTextBox1->TabIndex = 0;
			this->richTextBox1->Text = L"";
			// 
			// Table
			// 
			this->Table->AllowUserToAddRows = false;
			this->Table->AllowUserToDeleteRows = false;
			this->Table->AllowUserToResizeColumns = false;
			this->Table->AllowUserToResizeRows = false;
			this->Table->BackgroundColor = System::Drawing::Color::Lavender;
			this->Table->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Table->GridColor = System::Drawing::Color::LightBlue;
			this->Table->Location = System::Drawing::Point(12, 147);
			this->Table->Name = L"Table";
			this->Table->Size = System::Drawing::Size(240, 249);
			this->Table->TabIndex = 9;
			// 
			// textBox3
			// 
			this->textBox3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 24, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->textBox3->Location = System::Drawing::Point(6, 34);
			this->textBox3->Maximum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 2000000, 0, 0, 0 });
			this->textBox3->Minimum = System::Decimal(gcnew cli::array< System::Int32 >(4) { 2000000, 0, 0, System::Int32::MinValue });
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(173, 44);
			this->textBox3->TabIndex = 7;
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(662, 408);
			this->Controls->Add(this->Table);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->gbGenerate);
			this->MaximumSize = System::Drawing::Size(678, 447);
			this->MinimumSize = System::Drawing::Size(678, 447);
			this->Name = L"MyForm";
			this->SizeGripStyle = System::Windows::Forms::SizeGripStyle::Show;
			this->Text = L"Search";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->gbGenerate->ResumeLayout(false);
			this->gbGenerate->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->txtTo))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->txtFrom))->EndInit();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->Table))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->textBox3))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
	}
			 
	private: System::Void button1_Click_1(System::Object^  sender, System::EventArgs^  e) 
	{
		//DataGridViewRow row;
		int from = 0, to = 0;
		if  (txtFrom->Text == "" || txtTo->Text == "")
		{
			MessageBox::Show("Enter a diapason", "Fatal Error",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
		}
		else
		{
			from = Convert::ToInt32(txtFrom->Text);
			to = Convert::ToInt32(txtTo->Text);
			if (to < from)
			{
				MessageBox::Show("Short diapason", "Fatal Error",
					MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
			}
			else
			{
				textBox3->Minimum = from;
				textBox3->Maximum = to;
				ABIn(from, to);
				b = true;
				if (abs(to - from) > 1000)
				{
					int *array = 0;
					Generator::generate(array, from, to);
					Table->RowCount = SIZE;
					Table->ColumnCount = 2;
					for (int i = 0; i < SIZE; i++)
					{
						Table->Rows[i]->Cells[0]->Value = i + 1;
						Table->Rows[i]->Cells[1]->Value = array[i];
					}
					InFile(array, SIZE);
				}
				else
				{
					MessageBox::Show("Short diapason", "Fatal Error",
						MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
				}
			}
		}
	}

			private: bool FirstTest(int K, int a, int b)
			 {
				 if (K > b || K<a)
				 {
					 return false;
				 }
				 else
				 {
					 return true;
				 }
			 }

	private: void Finding()
	{

		if (!b)
		{
			MessageBox::Show("Enter a diapason", "Fatal Error",
				MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
		}
		else
		{
			if (textBox3->Text == "")
			{
				MessageBox::Show("Enter an object", "Fatal Error",
					MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
			}
			else
			{
				int element = Convert::ToInt32(textBox3->Text);
				if (!radioButton1->Checked && !radioButton2->Checked && !radioButton3->Checked && !radioButton4->Checked)
				{
					MessageBox::Show("Chose type of searching", "Fatal Error",
						MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
				}
				else
				{
					int *ab = ABOut();
					int d = ab[0];
					d = ab[1];
					if (!FirstTest(element, ab[0], ab[1]))
					{
						MessageBox::Show("Out of Range", "Fatal Error",
							MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
					}
					else
					{
						//time_t seconds = time(NULL);
						//tm *time1 , *time2;
						clock_t start, end;
						int size = Table->RowCount;
						int *array = new int[size];
						int result = 0;
						FromFile(array, size);
						if (radioButton1->Checked)
						{
							start = clock();
							for (int i = 0; i < N; i++)
							{
								result = Searching::linear(array, element, size);
							}
							end = clock();
							TIME->Text = Convert::ToString(1000 * ((double)end - (double)start) / ((double)CLOCKS_PER_SEC) / N);
							TIME->Text += " mls";
							if (result == -1)
							{
								MessageBox::Show("Nothis was found", "Fatal Error",
									MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
							}
							else
							{
								int test = 0;
								//int iter = 0;
								test = selectedOut();
								if (test > SIZE)
								{
									test = 0;
								}
								Table->Rows[test]->Selected = false;
								Table->Rows[result]->Selected = true;
								selectedIn(result);
								richTextBox1->Text = Convert::ToString(result + 1);
								int iter = IterationOut();
								Iteration->Text = Convert::ToString(iter);
							}
						}
						else
						{
							if (radioButton2->Checked)
							{
								start = clock();
								Sorting::buble(array, SIZE);
								InFile(array, SIZE);
								for (int i = 0; i < size; i++)
								{
									Table->Rows[i]->Cells[1]->Value = array[i];
								}
								int test = 0;
								test = selectedOut();
								if (test > SIZE)
								{
									test = 0;
								}
								Table->Rows[test]->Selected = false;
								//const int n = 500;
								for (int i = 0; i < N; i++)
								{
									result = Searching::Binary(array, element, SIZE, 0, SIZE - 1);

								}
								end = clock();
								if (result != -1)
								{
									TIME->Text = Convert::ToString(1000 * ((double)end - (double)start) / ((double)CLOCKS_PER_SEC) / N);
									TIME->Text += " mls";
									richTextBox1->Text = Convert::ToString(result + 1);
									Table->Rows[result]->Selected = true;
									selectedIn(result);
									int iter = IterationOut();
									Iteration->Text = Convert::ToString(iter);
								}
								else
								{
									MessageBox::Show("Nothis was found", "Fatal Error",
										MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
								}
							}
							else
							{
								if (radioButton3->Checked)
								{
									start = clock();
									Sorting::buble(array, SIZE);
									InFile(array, SIZE);
									for (int i = 0; i < size; i++)
									{
										Table->Rows[i]->Cells[1]->Value = array[i];
									}
									int test = 0;
									test = selectedOut();
									if (test > SIZE)
									{
										test = 0;
									}
									Table->Rows[test]->Selected = false;
									result = 0;
									for (int i = 0; i < N; i++)
									{
										result = Searching::ABinary(array, element, SIZE);
									}
									end = clock();
									if (result != -1 && result < SIZE)
									{
										TIME->Text = Convert::ToString(1000 * ((double)end - (double)start) / ((double)CLOCKS_PER_SEC) / N);
										TIME->Text += " mls";
										richTextBox1->Text = Convert::ToString(result + 1);
										Table->Rows[result]->Selected = true;
										selectedIn(result);
										int iter = IterationOut();
										Iteration->Text = Convert::ToString(iter);
									}
									else
									{
										MessageBox::Show("Nothis was found", "Fatal Error",
											MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
									}
								}
								else
								{
									start = clock();
									Sorting::buble(array, SIZE);
									InFile(array, SIZE);
									for (int i = 0; i < size; i++)
									{
										Table->Rows[i]->Cells[1]->Value = array[i];
									}
									int test = 0;
									test = selectedOut();
									if (test > SIZE)
									{
										test = 0;
									}
									Table->Rows[test]->Selected = false;
									result = 0;
									for (int i = 0; i < N; i++)
									{
										result = Searching::Shara(array, element, SIZE);
									}
									end = clock();
									if (result != -1)
									{
										TIME->Text = Convert::ToString(1000 * ((double)end - (double)start) / ((double)CLOCKS_PER_SEC) / N);
										TIME->Text += " mls";
										richTextBox1->Text = Convert::ToString(result + 1);
										Table->Rows[result]->Selected = true;
										selectedIn(result);
										int iter = IterationOut();
										Iteration->Text = Convert::ToString(iter);
									}
									else
									{
										MessageBox::Show("Nothis was found", "Fatal Error",
											MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
									}
								}
							}
						}
					}
				}

			}
		}
	}
		
	

private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) 
{
	Finding();
}
};
}
