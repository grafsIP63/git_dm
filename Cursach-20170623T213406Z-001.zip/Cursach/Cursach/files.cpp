#pragma once
#include <fstream>
#include <iostream>

using namespace std;

void  InFile(int *&array, int size)
{
	ofstream out;
	out.open("data.info");
	for (int i = 0; i<size - 1; i++)
	{
		out << array[i] << " ";
	}
	out << array[size - 1];
}

void FromFile(int *&array, int size)
{
	ifstream in;
	in.open("data.info");
	for (int i = 0; i < size; i++)
	{
		in >> array[i];
	}

}

void selectedIn(int number)
{
	ofstream out;
	out.open("selected.data");
	out << number;
}

int selectedOut()
{
	ifstream out("selected.data");
	int result;
	out >> result;
	return result;
}

void IterationIn(int sum)
{
	ofstream out;
	out.open("iteration.data" , ios_base::trunc);
	out << sum;
	out.close();
}

int IterationOut()
{
	ifstream in("iteration.data");
	int result = 0;
	in >> result;
	return result;
	in.close();
}

void ABIn(int a,int b)
{
	ofstream out;
	out.open("ab.data", ios_base::trunc);
	out <<a<<" "<<b;
	out.close();
}

int* ABOut()
{
	ifstream in("ab.data");
	int result[2];
	in >> result[0]>>result[1];
	return result;
	in.close();
}