#pragma once

#define SIZE 1000

namespace Generator
{

	int Linear(int *array, int element, int size);

	void generate(int *&array, int from, int to);
}